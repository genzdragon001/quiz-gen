# Online Quiz Generator — Implementation Plan

> **For Hermes:** Use subagent-driven-development skill to implement this plan task-by-task.

**Goal:** Build a PHP/MySQL online quiz system with student quiz-taking (anti-cheat) and faculty management (quizzes, questions, students, grades, email delivery).

**Architecture:** Monolithic PHP app with REST-style API endpoints. Vanilla JS frontend with no framework. MySQL for relational data. PHPMailer for email. Deployed on Hostinger shared hosting.

**Tech Stack:** PHP 8.x, MySQL 5.7+, Vanilla JS (ES6), PHPMailer 6.x, HTML5/CSS3

**Project root:** `C:\python_script\quiz-gen\`

---

## Phase 1: Database Schema + Config

### Task 1.1: Create database schema

**Objective:** Write the full `schema.sql` with all 6 tables.

**Files:**
- Create: `schema.sql`

**Step 1: Write schema.sql**

```sql
-- Online Quiz Generator Database Schema
-- Run this on Hostinger MySQL (phpMyAdmin or import)

CREATE DATABASE IF NOT EXISTS quiz_generator
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE quiz_generator;

-- Faculty accounts
CREATE TABLE faculty (
    faculty_id   INT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100) NOT NULL,
    email        VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Students (pre-registered by faculty)
CREATE TABLE students (
    student_id   VARCHAR(30) PRIMARY KEY,
    name         VARCHAR(150) NOT NULL,
    email        VARCHAR(150) DEFAULT NULL,
    year_section VARCHAR(50) DEFAULT NULL,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Quizzes
CREATE TABLE quizzes (
    quiz_id          INT AUTO_INCREMENT PRIMARY KEY,
    faculty_id       INT NOT NULL,
    title            VARCHAR(200) NOT NULL,
    type             ENUM('MCQ','TF') NOT NULL,
    time_limit_minutes INT NOT NULL DEFAULT 30,
    is_active        TINYINT(1) NOT NULL DEFAULT 0,
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Questions (correct_answer is NEVER sent to student browser)
CREATE TABLE questions (
    question_id    INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id        INT NOT NULL,
    question_text  TEXT NOT NULL,
    option_a       VARCHAR(500) DEFAULT NULL,
    option_b       VARCHAR(500) DEFAULT NULL,
    option_c       VARCHAR(500) DEFAULT NULL,
    option_d       VARCHAR(500) DEFAULT NULL,
    correct_answer CHAR(1) NOT NULL COMMENT 'A/B/C/D for MCQ, T/F for TF',
    sort_order     INT NOT NULL DEFAULT 0,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(quiz_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Student quiz submissions
CREATE TABLE submissions (
    submission_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id    VARCHAR(30) NOT NULL,
    quiz_id       INT NOT NULL,
    email_used    VARCHAR(150) NOT NULL,
    score         INT NOT NULL DEFAULT 0,
    total_items   INT NOT NULL,
    started_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    submitted_at  TIMESTAMP NULL,
    violations    INT NOT NULL DEFAULT 0 COMMENT 'tab-switch count',
    flagged       TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'auto-submitted due to violations',
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (quiz_id) REFERENCES quizzes(quiz_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Individual answers
CREATE TABLE answers (
    answer_id      INT AUTO_INCREMENT PRIMARY KEY,
    submission_id  INT NOT NULL,
    question_id    INT NOT NULL,
    student_answer CHAR(1) DEFAULT NULL COMMENT 'NULL = unanswered',
    is_correct     TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (submission_id) REFERENCES submissions(submission_id) ON DELETE CASCADE,
    FOREIGN KEY (question_id) REFERENCES questions(question_id) ON DELETE CASCADE
) ENGINE=InnoDB;
```

**Step 2: Verify**
- Check: 6 tables, all foreign keys, correct ENUMs, correct column types
- No syntax errors

---

### Task 1.2: Create config files

**Objective:** Database connection + app constants.

**Files:**
- Create: `config/database.php`
- Create: `config/config.php`

**Step 1: Write config/database.php**

```php
<?php
// Database connection (PDO)
// Update credentials for Hostinger

define('DB_HOST', 'localhost');
define('DB_NAME', 'quiz_generator');
define('DB_USER', 'root');       // CHANGE for production
define('DB_PASS', '');           // CHANGE for production

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}
```

**Step 2: Write config/config.php**

```php
<?php
// Application configuration

define('APP_NAME', 'Online Quiz Generator');
define('BASE_URL', 'http://localhost/quiz-gen/');  // CHANGE for production

// SMTP settings for PHPMailer (Hostinger)
define('SMTP_HOST', 'smtp.hostinger.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'noreply@yourdomain.com');  // CHANGE
define('SMTP_PASS', 'your-smtp-password');      // CHANGE
define('SMTP_FROM', 'noreply@yourdomain.com');  // CHANGE
define('SMTP_FROM_NAME', 'Online Quiz System');

// Anti-cheat
define('MAX_VIOLATIONS', 3);  // tab-switch strikes before auto-submit

// Session
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
session_start();
```

**Step 3: Verify**
- Both files parse without errors
- No hardcoded production credentials committed (use placeholders)

---

## Phase 2: Faculty Authentication

### Task 2.1: Faculty login page + API

**Objective:** Faculty can log in with email + password. PHP session-based auth.

**Files:**
- Create: `faculty/login.php`
- Create: `api/faculty/login.php`
- Create: `api/faculty/logout.php`
- Create: `includes/auth.php`

**Step 1: Write includes/auth.php (session guard)**

```php
<?php
// Require this at the top of any faculty-only page
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

function requireFaculty(): array {
    if (empty($_SESSION['faculty_id'])) {
        header('Location: ' . BASE_URL . 'faculty/login.php');
        exit;
    }
    return [
        'faculty_id' => $_SESSION['faculty_id'],
        'name'       => $_SESSION['faculty_name'],
    ];
}

function isFacultyLoggedIn(): bool {
    return !empty($_SESSION['faculty_id']);
}
```

**Step 2: Write api/faculty/login.php**

```php
<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$email    = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    http_response_code(400);
    echo json_encode(['error' => 'Email and password are required']);
    exit;
}

$pdo  = getDB();
$stmt = $pdo->prepare("SELECT faculty_id, name, password_hash FROM faculty WHERE email = ?");
$stmt->execute([$email]);
$faculty = $stmt->fetch();

if (!$faculty || !password_verify($password, $faculty['password_hash'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid email or password']);
    exit;
}

$_SESSION['faculty_id']   = $faculty['faculty_id'];
$_SESSION['faculty_name'] = $faculty['name'];

echo json_encode([
    'success'     => true,
    'faculty_id'  => $faculty['faculty_id'],
    'name'        => $faculty['name'],
    'redirect'    => BASE_URL . 'faculty/dashboard.php',
]);
```

**Step 3: Write api/faculty/logout.php**

```php
<?php
require_once __DIR__ . '/../../config/config.php';

session_destroy();
header('Location: ' . BASE_URL . 'faculty/login.php');
exit;
```

**Step 4: Write faculty/login.php (HTML form)**

```html
<?php
require_once __DIR__ . '/../config/config.php';
// If already logged in, redirect to dashboard
if (!empty($_SESSION['faculty_id'])) {
    header('Location: ' . BASE_URL . 'faculty/dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Login — <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="login-container">
    <h1>Faculty Login</h1>
    <form id="loginForm">
        <label>Email: <input type="email" name="email" required></label>
        <label>Password: <input type="password" name="password" required></label>
        <button type="submit">Login</button>
    </form>
    <p id="error" style="color:red;display:none;"></p>
</div>
<script>
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const resp = await fetch('<?= BASE_URL ?>api/faculty/login.php', {
        method: 'POST',
        body: form
    });
    const data = await resp.json();
    if (data.success) {
        window.location.href = data.redirect;
    } else {
        document.getElementById('error').textContent = data.error;
        document.getElementById('error').style.display = 'block';
    }
});
</script>
</body>
</html>
```

**Step 5: Verify**
- Login form renders
- Invalid credentials show error
- Valid credentials redirect to dashboard
- Session persists across pages

---

### Task 2.2: Faculty dashboard shell

**Objective:** Basic dashboard page with navigation skeleton.

**Files:**
- Create: `faculty/dashboard.php`
- Create: `includes/header.php`
- Create: `includes/footer.php`

**Step 1: Write includes/header.php**

```php
<?php
require_once __DIR__ . '/auth.php';
$faculty = requireFaculty();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= APP_NAME ?> — Faculty</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<nav class="faculty-nav">
    <span class="brand"><?= APP_NAME ?></span>
    <a href="<?= BASE_URL ?>faculty/dashboard.php">Dashboard</a>
    <a href="<?= BASE_URL ?>faculty/quiz-create.php">New Quiz</a>
    <a href="<?= BASE_URL ?>faculty/students.php">Students</a>
    <a href="<?= BASE_URL ?>faculty/grades.php">Grades</a>
    <span class="user"><?= htmlspecialchars($faculty['name']) ?></span>
    <a href="<?= BASE_URL ?>api/faculty/logout.php">Logout</a>
</nav>
<main>
```

**Step 2: Write includes/footer.php**

```php
</main>
</body>
</html>
```

**Step 3: Write faculty/dashboard.php**

```php
<?php
require_once __DIR__ . '/../includes/header.php';

$pdo = getDB();
$stmt = $pdo->prepare("SELECT COUNT(*) FROM quizzes WHERE faculty_id = ?");
$stmt->execute([$faculty['faculty_id']]);
$quizCount = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM students");
$stmt->execute();
$studentCount = $stmt->fetchColumn();

$stmt = $pdo->prepare(
    "SELECT COUNT(*) FROM submissions s JOIN quizzes q ON s.quiz_id = q.quiz_id WHERE q.faculty_id = ?"
);
$stmt->execute([$faculty['faculty_id']]);
$submissionCount = $stmt->fetchColumn();
?>

<h1>Dashboard</h1>
<div class="stats">
    <div class="stat-card">
        <h3><?= $quizCount ?></h3>
        <p>Quizzes</p>
    </div>
    <div class="stat-card">
        <h3><?= $studentCount ?></h3>
        <p>Students</p>
    </div>
    <div class="stat-card">
        <h3><?= $submissionCount ?></h3>
        <p>Submissions</p>
    </div>
</div>

<h2>Your Quizzes</h2>
<table>
    <thead>
        <tr><th>Title</th><th>Type</th><th>Status</th><th>Actions</th></tr>
    </thead>
    <tbody>
    <?php
    $stmt = $pdo->prepare("SELECT * FROM quizzes WHERE faculty_id = ? ORDER BY created_at DESC");
    $stmt->execute([$faculty['faculty_id']]);
    while ($quiz = $stmt->fetch()):
    ?>
        <tr>
            <td><?= htmlspecialchars($quiz['title']) ?></td>
            <td><?= $quiz['type'] === 'MCQ' ? 'Multiple Choice' : 'True/False' ?></td>
            <td><?= $quiz['is_active'] ? 'Active' : 'Inactive' ?></td>
            <td>
                <a href="quiz-edit.php?id=<?= $quiz['quiz_id'] ?>">Edit</a>
                <a href="grades.php?quiz_id=<?= $quiz['quiz_id'] ?>">Grades</a>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
```

**Step 4: Verify**
- Dashboard loads after login
- Stats show correct counts (0 for now)
- Navigation links work
- Logout clears session

---

## Phase 3: Faculty — Quiz + Question Management

### Task 3.1: Create quiz form + API

**Objective:** Faculty can create a new quiz with title, type, time limit, active status.

**Files:**
- Create: `faculty/quiz-create.php`
- Create: `api/faculty/quizzes.php` (handles POST create + GET list)

**Step 1: Write api/faculty/quizzes.php**

```php
<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';

$faculty = requireFaculty();
header('Content-Type: application/json');

$pdo = getDB();

// CREATE quiz
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title            = trim($_POST['title'] ?? '');
    $type             = $_POST['type'] ?? '';
    $timeLimitMinutes = (int)($_POST['time_limit_minutes'] ?? 30);
    $isActive         = isset($_POST['is_active']) ? 1 : 0;

    if (empty($title) || !in_array($type, ['MCQ', 'TF'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Title and valid type (MCQ or TF) are required']);
        exit;
    }

    $stmt = $pdo->prepare(
        "INSERT INTO quizzes (faculty_id, title, type, time_limit_minutes, is_active) VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->execute([$faculty['faculty_id'], $title, $type, $timeLimitMinutes, $isActive]);

    echo json_encode([
        'success' => true,
        'quiz_id' => $pdo->lastInsertId(),
    ]);
    exit;
}

// LIST quizzes (for this faculty)
$stmt = $pdo->prepare("SELECT * FROM quizzes WHERE faculty_id = ? ORDER BY created_at DESC");
$stmt->execute([$faculty['faculty_id']]);
echo json_encode($stmt->fetchAll());
```

**Step 2: Write faculty/quiz-create.php**

```php
<?php require_once __DIR__ . '/../includes/header.php'; ?>

<h1>Create New Quiz</h1>
<form id="quizForm">
    <label>Title: <input type="text" name="title" required></label>
    <label>Type:
        <select name="type" required>
            <option value="MCQ">Multiple Choice</option>
            <option value="TF">True or False</option>
        </select>
    </label>
    <label>Time Limit (minutes): <input type="number" name="time_limit_minutes" value="30" min="1" required></label>
    <label><input type="checkbox" name="is_active"> Active (students can take it)</label>
    <button type="submit">Create Quiz</button>
</form>
<p id="msg"></p>

<script>
document.getElementById('quizForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const resp = await fetch('<?= BASE_URL ?>api/faculty/quizzes.php', { method: 'POST', body: form });
    const data = await resp.json();
    if (data.success) {
        document.getElementById('msg').textContent = 'Quiz created! Quiz ID: ' + data.quiz_id;
        document.getElementById('msg').style.color = 'green';
        // Optionally redirect to add questions
        // window.location.href = 'quiz-edit.php?id=' + data.quiz_id;
    } else {
        document.getElementById('msg').textContent = data.error;
        document.getElementById('msg').style.color = 'red';
    }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
```

**Step 3: Verify**
- Create a quiz, check DB
- Quiz appears on dashboard
- Validation rejects empty title / bad type

---

### Task 3.2: Edit quiz + manage questions

**Objective:** Faculty can edit quiz details and add/remove questions.

**Files:**
- Create: `faculty/quiz-edit.php`
- Create: `api/faculty/questions.php` (CRUD for questions)

**Step 1: Write api/faculty/questions.php**

```php
<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';

$faculty = requireFaculty();
header('Content-Type: application/json');
$pdo = getDB();

// Helper: verify quiz belongs to this faculty
function verifyQuizOwnership(PDO $pdo, int $quizId, int $facultyId): bool {
    $stmt = $pdo->prepare("SELECT 1 FROM quizzes WHERE quiz_id = ? AND faculty_id = ?");
    $stmt->execute([$quizId, $facultyId]);
    return (bool)$stmt->fetch();
}

$quizId = (int)($_REQUEST['quiz_id'] ?? 0);
if (!$quizId || !verifyQuizOwnership($pdo, $quizId, $faculty['faculty_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Quiz not found or access denied']);
    exit;
}

// CREATE question
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $questionText  = trim($_POST['question_text'] ?? '');
    $correctAnswer = strtoupper(trim($_POST['correct_answer'] ?? ''));
    $optionA = trim($_POST['option_a'] ?? '');
    $optionB = trim($_POST['option_b'] ?? '');
    $optionC = trim($_POST['option_c'] ?? '');
    $optionD = trim($_POST['option_d'] ?? '');

    if (empty($questionText) || empty($correctAnswer)) {
        http_response_code(400);
        echo json_encode(['error' => 'Question text and correct answer are required']);
        exit;
    }

    // Get quiz type to validate answer format
    $stmt = $pdo->prepare("SELECT type FROM quizzes WHERE quiz_id = ?");
    $stmt->execute([$quizId]);
    $quiz = $stmt->fetch();

    if ($quiz['type'] === 'TF' && !in_array($correctAnswer, ['T', 'F'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Correct answer must be T or F for True/False quizzes']);
        exit;
    }
    if ($quiz['type'] === 'MCQ' && !in_array($correctAnswer, ['A', 'B', 'C', 'D'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Correct answer must be A, B, C, or D for MCQ quizzes']);
        exit;
    }

    // Get next sort_order
    $stmt = $pdo->prepare("SELECT COALESCE(MAX(sort_order), 0) + 1 FROM questions WHERE quiz_id = ?");
    $stmt->execute([$quizId]);
    $sortOrder = $stmt->fetchColumn();

    $stmt = $pdo->prepare(
        "INSERT INTO questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_answer, sort_order)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->execute([$quizId, $questionText, $optionA, $optionB, $optionC, $optionD, $correctAnswer, $sortOrder]);

    echo json_encode(['success' => true, 'question_id' => $pdo->lastInsertId()]);
    exit;
}

// DELETE question
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    parse_str(file_get_contents("php://input"), $data);
    $questionId = (int)($data['question_id'] ?? 0);

    $stmt = $pdo->prepare("DELETE FROM questions WHERE question_id = ? AND quiz_id = ?");
    $stmt->execute([$questionId, $quizId]);

    echo json_encode(['success' => true]);
    exit;
}

// LIST questions (WITHOUT correct_answer — safe for student API reuse)
$stmt = $pdo->prepare(
    "SELECT question_id, question_text, option_a, option_b, option_c, option_d, sort_order
     FROM questions WHERE quiz_id = ? ORDER BY sort_order"
);
$stmt->execute([$quizId]);
echo json_encode($stmt->fetchAll());
```

**Step 2: Write faculty/quiz-edit.php**

```php
<?php
require_once __DIR__ . '/../includes/header.php';

$quizId = (int)($_GET['id'] ?? 0);
if (!$quizId) {
    echo "<p>Invalid quiz ID.</p>";
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}

$pdo = getDB();
$stmt = $pdo->prepare("SELECT * FROM quizzes WHERE quiz_id = ? AND faculty_id = ?");
$stmt->execute([$quizId, $faculty['faculty_id']]);
$quiz = $stmt->fetch();

if (!$quiz) {
    echo "<p>Quiz not found.</p>";
    require_once __DIR__ . '/../includes/footer.php';
    exit;
}
?>

<h1>Edit: <?= htmlspecialchars($quiz['title']) ?></h1>
<p>Quiz ID: <strong><?= $quiz['quiz_id'] ?></strong> (share this with students)</p>

<!-- Quiz settings form -->
<form id="quizSettings">
    <input type="hidden" name="quiz_id" value="<?= $quiz['quiz_id'] ?>">
    <label>Title: <input type="text" name="title" value="<?= htmlspecialchars($quiz['title']) ?>" required></label>
    <label>Time Limit (min): <input type="number" name="time_limit_minutes" value="<?= $quiz['time_limit_minutes'] ?>" min="1"></label>
    <label><input type="checkbox" name="is_active" <?= $quiz['is_active'] ? 'checked' : '' ?>> Active</label>
    <button type="submit">Save Settings</button>
</form>

<hr>

<!-- Add question form -->
<h2>Add Question</h2>
<form id="questionForm">
    <input type="hidden" name="quiz_id" value="<?= $quiz['quiz_id'] ?>">
    <label>Question: <textarea name="question_text" required></textarea></label>
    <?php if ($quiz['type'] === 'MCQ'): ?>
        <label>A: <input type="text" name="option_a" required></label>
        <label>B: <input type="text" name="option_b" required></label>
        <label>C: <input type="text" name="option_c" required></label>
        <label>D: <input type="text" name="option_d" required></label>
        <label>Correct Answer:
            <select name="correct_answer" required>
                <option value="A">A</option>
                <option value="B">B</option>
                <option value="C">C</option>
                <option value="D">D</option>
            </select>
        </label>
    <?php else: ?>
        <label>Correct Answer:
            <select name="correct_answer" required>
                <option value="T">True</option>
                <option value="F">False</option>
            </select>
        </label>
    <?php endif; ?>
    <button type="submit">Add Question</button>
</form>

<hr>

<!-- Question list -->
<h2>Questions (<?= $quiz['type'] === 'MCQ' ? 'Multiple Choice' : 'True/False' ?>)</h2>
<div id="questionList">Loading...</div>

<script>
const quizId = <?= $quiz['quiz_id'] ?>;

async function loadQuestions() {
    const resp = await fetch(`<?= BASE_URL ?>api/faculty/questions.php?quiz_id=${quizId}`);
    const questions = await resp.json();
    const container = document.getElementById('questionList');
    if (!questions.length) {
        container.innerHTML = '<p>No questions yet.</p>';
        return;
    }
    container.innerHTML = questions.map((q, i) => `
        <div class="question-item">
            <strong>${i + 1}. ${q.question_text}</strong>
            ${q.option_a ? `<br>A: ${q.option_a}` : ''}
            ${q.option_b ? `<br>B: ${q.option_b}` : ''}
            ${q.option_c ? `<br>C: ${q.option_c}` : ''}
            ${q.option_d ? `<br>D: ${q.option_d}` : ''}
            <br><button onclick="deleteQuestion(${q.question_id})">Delete</button>
        </div>
    `).join('');
}

async function deleteQuestion(qid) {
    if (!confirm('Delete this question?')) return;
    await fetch('<?= BASE_URL ?>api/faculty/questions.php?quiz_id=' + quizId, {
        method: 'DELETE',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'question_id=' + qid
    });
    loadQuestions();
}

document.getElementById('questionForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const resp = await fetch('<?= BASE_URL ?>api/faculty/questions.php?quiz_id=' + quizId, {
        method: 'POST',
        body: form
    });
    const data = await resp.json();
    if (data.success) {
        e.target.reset();
        loadQuestions();
    } else {
        alert(data.error);
    }
});

loadQuestions();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
```

**Step 3: Verify**
- Edit page loads with quiz data
- Add MCQ question → appears in list
- Add TF question → only T/F answer options
- Delete question works
- Quiz settings save

---

## Phase 4: Faculty — Student Management

### Task 4.1: Student CRUD

**Objective:** Faculty can add, edit, delete students. Student ID is the primary key.

**Files:**
- Create: `faculty/students.php`
- Create: `api/faculty/students.php`

**Step 1: Write api/faculty/students.php**

```php
<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';

$faculty = requireFaculty();
header('Content-Type: application/json');
$pdo = getDB();

// CREATE student
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentId   = trim($_POST['student_id'] ?? '');
    $name        = trim($_POST['name'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $yearSection = trim($_POST['year_section'] ?? '');

    if (empty($studentId) || empty($name)) {
        http_response_code(400);
        echo json_encode(['error' => 'Student ID and name are required']);
        exit;
    }

    // Check for duplicate
    $stmt = $pdo->prepare("SELECT 1 FROM students WHERE student_id = ?");
    $stmt->execute([$studentId]);
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['error' => 'Student ID already exists']);
        exit;
    }

    $stmt = $pdo->prepare(
        "INSERT INTO students (student_id, name, email, year_section) VALUES (?, ?, ?, ?)"
    );
    $stmt->execute([$studentId, $name, $email, $yearSection]);

    echo json_encode(['success' => true]);
    exit;
}

// UPDATE student
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    parse_str(file_get_contents("php://input"), $data);
    $studentId   = trim($data['student_id'] ?? '');
    $name        = trim($data['name'] ?? '');
    $email       = trim($data['email'] ?? '');
    $yearSection = trim($data['year_section'] ?? '');

    $stmt = $pdo->prepare(
        "UPDATE students SET name = ?, email = ?, year_section = ? WHERE student_id = ?"
    );
    $stmt->execute([$name, $email, $yearSection, $studentId]);

    echo json_encode(['success' => true]);
    exit;
}

// DELETE student
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    parse_str(file_get_contents("php://input"), $data);
    $studentId = trim($data['student_id'] ?? '');

    $stmt = $pdo->prepare("DELETE FROM students WHERE student_id = ?");
    $stmt->execute([$studentId]);

    echo json_encode(['success' => true]);
    exit;
}

// LIST students (with search)
$search = trim($_GET['search'] ?? '');
if ($search) {
    $stmt = $pdo->prepare(
        "SELECT * FROM students WHERE student_id LIKE ? OR name LIKE ? ORDER BY name"
    );
    $stmt->execute(["%$search%", "%$search%"]);
} else {
    $stmt = $pdo->query("SELECT * FROM students ORDER BY name");
}
echo json_encode($stmt->fetchAll());
```

**Step 2: Write faculty/students.php**

```php
<?php require_once __DIR__ . '/../includes/header.php'; ?>

<h1>Student Management</h1>

<!-- Add student form -->
<h2>Add Student</h2>
<form id="studentForm">
    <label>Student ID: <input type="text" name="student_id" required></label>
    <label>Full Name: <input type="text" name="name" required></label>
    <label>Email: <input type="email" name="email"></label>
    <label>Year & Section: <input type="text" name="year_section"></label>
    <button type="submit">Add Student</button>
</form>
<p id="formMsg"></p>

<hr>

<!-- Search + list -->
<h2>Student List</h2>
<input type="text" id="searchBox" placeholder="Search by ID or name...">
<table>
    <thead>
        <tr><th>Student ID</th><th>Name</th><th>Email</th><th>Year/Section</th><th>Actions</th></tr>
    </thead>
    <tbody id="studentTable"></tbody>
</table>

<script>
async function loadStudents(search = '') {
    const resp = await fetch(`<?= BASE_URL ?>api/faculty/students.php?search=${encodeURIComponent(search)}`);
    const students = await resp.json();
    document.getElementById('studentTable').innerHTML = students.map(s => `
        <tr>
            <td>${s.student_id}</td>
            <td>${s.name}</td>
            <td>${s.email || '-'}</td>
            <td>${s.year_section || '-'}</td>
            <td>
                <button onclick="editStudent('${s.student_id}')">Edit</button>
                <button onclick="deleteStudent('${s.student_id}')">Delete</button>
            </td>
        </tr>
    `).join('') || '<tr><td colspan="5">No students found.</td></tr>';
}

document.getElementById('studentForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const resp = await fetch('<?= BASE_URL ?>api/faculty/students.php', { method: 'POST', body: form });
    const data = await resp.json();
    const msg = document.getElementById('formMsg');
    if (data.success) {
        msg.textContent = 'Student added!';
        msg.style.color = 'green';
        e.target.reset();
        loadStudents();
    } else {
        msg.textContent = data.error;
        msg.style.color = 'red';
    }
});

async function deleteStudent(sid) {
    if (!confirm(`Delete student ${sid}?`)) return;
    await fetch('<?= BASE_URL ?>api/faculty/students.php', {
        method: 'DELETE',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'student_id=' + encodeURIComponent(sid)
    });
    loadStudents();
}

document.getElementById('searchBox').addEventListener('input', (e) => {
    loadStudents(e.target.value);
});

loadStudents();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
```

**Step 3: Verify**
- Add a student → appears in list
- Duplicate student ID → error
- Search filters by ID or name
- Delete removes student

---

## Phase 5: Student Quiz Engine

### Task 5.1: Student landing + verification

**Objective:** Student enters Student ID + Quiz ID, system verifies both exist and quiz is active.

**Files:**
- Create: `index.php` (root redirect)
- Create: `student/index.php` (landing page)
- Create: `api/student/verify.php`

**Step 1: Write index.php (root redirect)**

```php
<?php
header('Location: student/');
exit;
```

**Step 2: Write api/student/verify.php**

```php
<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$studentId = trim($_POST['student_id'] ?? '');
$quizId    = (int)($_POST['quiz_id'] ?? 0);

if (empty($studentId) || !$quizId) {
    http_response_code(400);
    echo json_encode(['error' => 'Student ID and Quiz ID are required']);
    exit;
}

$pdo = getDB();

// Check student exists
$stmt = $pdo->prepare("SELECT student_id, name, email FROM students WHERE student_id = ?");
$stmt->execute([$studentId]);
$student = $stmt->fetch();

if (!$student) {
    http_response_code(404);
    echo json_encode(['error' => 'Student ID not found']);
    exit;
}

// Check quiz exists and is active
$stmt = $pdo->prepare("SELECT quiz_id, title, type, time_limit_minutes FROM quizzes WHERE quiz_id = ? AND is_active = 1");
$stmt->execute([$quizId]);
$quiz = $stmt->fetch();

if (!$quiz) {
    http_response_code(404);
    echo json_encode(['error' => 'Quiz not found or is not currently active']);
    exit;
}

// Check if student already submitted this quiz
$stmt = $pdo->prepare("SELECT 1 FROM submissions WHERE student_id = ? AND quiz_id = ?");
$stmt->execute([$studentId, $quizId]);
if ($stmt->fetch()) {
    http_response_code(409);
    echo json_encode(['error' => 'You have already taken this quiz']);
    exit;
}

echo json_encode([
    'success'    => true,
    'student'    => $student,
    'quiz'       => $quiz,
    'has_email'  => !empty($student['email']),
]);
```

**Step 3: Write student/index.php (landing page)**

```php
<?php require_once __DIR__ . '/../config/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="student-container">
    <h1><?= APP_NAME ?></h1>
    <form id="verifyForm">
        <label>Student ID: <input type="text" name="student_id" required autofocus></label>
        <label>Quiz ID: <input type="text" name="quiz_id" required></label>
        <button type="submit">Start Quiz</button>
    </form>
    <p id="error" style="color:red;display:none;"></p>
</div>

<script>
document.getElementById('verifyForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const resp = await fetch('<?= BASE_URL ?>api/student/verify.php', { method: 'POST', body: form });
    const data = await resp.json();

    if (data.success) {
        // Store in sessionStorage for next page
        sessionStorage.setItem('student', JSON.stringify(data.student));
        sessionStorage.setItem('quiz', JSON.stringify(data.quiz));
        window.location.href = 'email.php';
    } else {
        document.getElementById('error').textContent = data.error;
        document.getElementById('error').style.display = 'block';
    }
});
</script>
</body>
</html>
```

**Step 4: Verify**
- Valid student ID + active quiz → redirects to email page
- Invalid student ID → error
- Inactive quiz → error
- Already submitted → error

---

### Task 5.2: Email collection page

**Objective:** After verification, student must enter email before quiz starts.

**Files:**
- Create: `student/email.php`

**Step 1: Write student/email.php**

```php
<?php require_once __DIR__ . '/../config/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Email — <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="student-container">
    <h1>Enter Your Email</h1>
    <p>Your score will be sent to this email address.</p>
    <form id="emailForm">
        <label>Email: <input type="email" name="email" id="emailInput" required autofocus></label>
        <button type="submit">Start Quiz</button>
    </form>
    <p id="error" style="color:red;display:none;"></p>
</div>

<script>
// Restore student/quiz from sessionStorage
const student = JSON.parse(sessionStorage.getItem('student'));
const quiz = JSON.parse(sessionStorage.getItem('quiz'));

if (!student || !quiz) {
    window.location.href = 'index.php';
}

// Pre-fill email if student has one on file
if (student.email) {
    document.getElementById('emailInput').value = student.email;
}

document.getElementById('emailForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('emailInput').value.trim();
    if (!email) {
        document.getElementById('error').textContent = 'Email is required';
        document.getElementById('error').style.display = 'block';
        return;
    }
    // Store email and proceed
    sessionStorage.setItem('email', email);
    window.location.href = 'quiz.php';
});
</script>
</body>
</html>
```

**Step 2: Verify**
- Page loads with student/quiz data from sessionStorage
- Email pre-filled if student has one
- Empty email → error
- Valid email → proceeds to quiz

---

### Task 5.3: Quiz engine + anti-cheat

**Objective:** The core quiz page — loads questions (no answers), one at a time, with timer, anti-cheat measures.

**Files:**
- Create: `student/quiz.php`
- Create: `api/student/start-quiz.php`
- Create: `assets/js/quiz.js`

**Step 1: Write api/student/start-quiz.php**

```php
<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$studentId = trim($_POST['student_id'] ?? '');
$quizId    = (int)($_POST['quiz_id'] ?? 0);
$email     = trim($_POST['email'] ?? '');

if (empty($studentId) || !$quizId || empty($email)) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

$pdo = getDB();

// Verify again (belt and suspenders)
$stmt = $pdo->prepare("SELECT 1 FROM students WHERE student_id = ?");
$stmt->execute([$studentId]);
if (!$stmt->fetch()) {
    http_response_code(404);
    echo json_encode(['error' => 'Student not found']);
    exit;
}

$stmt = $pdo->prepare("SELECT quiz_id, title, type, time_limit_minutes FROM quizzes WHERE quiz_id = ? AND is_active = 1");
$stmt->execute([$quizId]);
$quiz = $stmt->fetch();
if (!$quiz) {
    http_response_code(404);
    echo json_encode(['error' => 'Quiz not available']);
    exit;
}

// Check for existing submission
$stmt = $pdo->prepare("SELECT 1 FROM submissions WHERE student_id = ? AND quiz_id = ?");
$stmt->execute([$studentId, $quizId]);
if ($stmt->fetch()) {
    http_response_code(409);
    echo json_encode(['error' => 'Already submitted']);
    exit;
}

// Create submission record
$stmt = $pdo->prepare(
    "INSERT INTO submissions (student_id, quiz_id, email_used, total_items, started_at)
     VALUES (?, ?, ?, (SELECT COUNT(*) FROM questions WHERE quiz_id = ?), NOW())"
);
$stmt->execute([$studentId, $quizId, $email, $quizId]);
$submissionId = $pdo->lastInsertId();

// Get questions WITHOUT correct_answer
$stmt = $pdo->prepare(
    "SELECT question_id, question_text, option_a, option_b, option_c, option_d, sort_order
     FROM questions WHERE quiz_id = ? ORDER BY sort_order"
);
$stmt->execute([$quizId]);
$questions = $stmt->fetchAll();

echo json_encode([
    'success'       => true,
    'submission_id' => $submissionId,
    'quiz'          => $quiz,
    'questions'     => $questions,
]);
```

**Step 2: Write student/quiz.php**

```php
<?php require_once __DIR__ . '/../config/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz — <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body class="quiz-body">
<div class="quiz-container">
    <div class="quiz-header">
        <h1 id="quizTitle"></h1>
        <div class="timer" id="timer">--:--</div>
        <div class="progress">Question <span id="currentQ">1</span> of <span id="totalQ">0</span></div>
    </div>

    <div class="question-card" id="questionCard">
        <p id="questionText"></p>
        <div id="optionsContainer"></div>
    </div>

    <div class="quiz-nav">
        <button id="prevBtn" disabled>Previous</button>
        <button id="nextBtn">Next</button>
        <button id="submitBtn" style="display:none;">Submit Quiz</button>
    </div>

    <div id="violationWarning" style="display:none;color:red;font-weight:bold;text-align:center;margin-top:1rem;"></div>
</div>

<script src="<?= BASE_URL ?>assets/js/quiz.js"></script>
</body>
</html>
```

**Step 3: Write assets/js/quiz.js**

```javascript
// ============================================================
// Quiz Engine + Anti-Cheat
// ============================================================

// --- State ---
let questions = [];
let currentIndex = 0;
let answers = {};        // { question_id: 'A'|'B'|'C'|'D'|'T'|'F'|null }
let submissionId = null;
let quizData = null;
let timeRemaining = 0;   // seconds
let timerInterval = null;
let violations = 0;
const MAX_VIOLATIONS = 3;

// --- Init ---
(async function init() {
    const student = JSON.parse(sessionStorage.getItem('student'));
    const quiz = JSON.parse(sessionStorage.getItem('quiz'));
    const email = sessionStorage.getItem('email');

    if (!student || !quiz || !email) {
        window.location.href = 'index.php';
        return;
    }

    // Start quiz on server
    const form = new FormData();
    form.append('student_id', student.student_id);
    form.append('quiz_id', quiz.quiz_id);
    form.append('email', email);

    const resp = await fetch('../api/student/start-quiz.php', { method: 'POST', body: form });
    const data = await resp.json();

    if (!data.success) {
        alert(data.error);
        window.location.href = 'index.php';
        return;
    }

    questions = data.questions;
    submissionId = data.submission_id;
    quizData = data.quiz;
    timeRemaining = quizData.time_limit_minutes * 60;

    document.getElementById('quizTitle').textContent = quizData.title;
    document.getElementById('totalQ').textContent = questions.length;

    if (questions.length === 0) {
        document.getElementById('questionText').textContent = 'This quiz has no questions.';
        return;
    }

    renderQuestion();
    startTimer();
    setupAntiCheat();
})();

// --- Render ---
function renderQuestion() {
    const q = questions[currentIndex];
    document.getElementById('currentQ').textContent = currentIndex + 1;
    document.getElementById('questionText').textContent = q.question_text;

    const container = document.getElementById('optionsContainer');
    const savedAnswer = answers[q.question_id];

    if (quizData.type === 'TF') {
        container.innerHTML = `
            <label class="option ${savedAnswer === 'T' ? 'selected' : ''}">
                <input type="radio" name="answer" value="T" ${savedAnswer === 'T' ? 'checked' : ''}
                       onchange="setAnswer(${q.question_id}, 'T')"> True
            </label>
            <label class="option ${savedAnswer === 'F' ? 'selected' : ''}">
                <input type="radio" name="answer" value="F" ${savedAnswer === 'F' ? 'checked' : ''}
                       onchange="setAnswer(${q.question_id}, 'F')"> False
            </label>
        `;
    } else {
        const options = [
            { key: 'A', text: q.option_a },
            { key: 'B', text: q.option_b },
            { key: 'C', text: q.option_c },
            { key: 'D', text: q.option_d },
        ];
        container.innerHTML = options.map(o => `
            <label class="option ${savedAnswer === o.key ? 'selected' : ''}">
                <input type="radio" name="answer" value="${o.key}" ${savedAnswer === o.key ? 'checked' : ''}
                       onchange="setAnswer(${q.question_id}, '${o.key}')"> ${o.key}. ${o.text}
            </label>
        `).join('');
    }

    // Nav buttons
    document.getElementById('prevBtn').disabled = currentIndex === 0;
    if (currentIndex === questions.length - 1) {
        document.getElementById('nextBtn').style.display = 'none';
        document.getElementById('submitBtn').style.display = 'inline-block';
    } else {
        document.getElementById('nextBtn').style.display = 'inline-block';
        document.getElementById('submitBtn').style.display = 'none';
    }
}

function setAnswer(questionId, value) {
    answers[questionId] = value;
    renderQuestion();
}

// --- Navigation ---
document.getElementById('prevBtn').addEventListener('click', () => {
    if (currentIndex > 0) {
        currentIndex--;
        renderQuestion();
    }
});

document.getElementById('nextBtn').addEventListener('click', () => {
    if (currentIndex < questions.length - 1) {
        currentIndex++;
        renderQuestion();
    }
});

document.getElementById('submitBtn').addEventListener('click', () => {
    if (confirm('Submit your quiz? You cannot change answers after submission.')) {
        submitQuiz();
    }
});

// --- Timer ---
function startTimer() {
    updateTimerDisplay();
    timerInterval = setInterval(() => {
        timeRemaining--;
        updateTimerDisplay();
        if (timeRemaining <= 0) {
            clearInterval(timerInterval);
            alert('Time is up! Your quiz will be submitted automatically.');
            submitQuiz();
        }
    }, 1000);
}

function updateTimerDisplay() {
    const mins = Math.floor(timeRemaining / 60);
    const secs = timeRemaining % 60;
    document.getElementById('timer').textContent =
        String(mins).padStart(2, '0') + ':' + String(secs).padStart(2, '0');

    // Flash red when under 60 seconds
    if (timeRemaining <= 60) {
        document.getElementById('timer').style.color = 'red';
    }
}

// --- Anti-Cheat ---
function setupAntiCheat() {
    // Disable right-click
    document.addEventListener('contextmenu', (e) => e.preventDefault());

    // Disable copy/paste/cut
    document.addEventListener('copy', (e) => e.preventDefault());
    document.addEventListener('paste', (e) => e.preventDefault());
    document.addEventListener('cut', (e) => e.preventDefault());

    // Disable keyboard shortcuts for copy/paste
    document.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && ['c', 'v', 'x', 'a', 'u'].includes(e.key.toLowerCase())) {
            e.preventDefault();
        }
        // Disable F12, Ctrl+Shift+I, Ctrl+Shift+J (dev tools)
        if (e.key === 'F12' ||
            (e.ctrlKey && e.shiftKey && ['I', 'J', 'C'].includes(e.key.toUpperCase()))) {
            e.preventDefault();
        }
    });

    // Tab switch detection
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
            recordViolation();
        }
    });

    window.addEventListener('blur', () => {
        recordViolation();
    });
}

function recordViolation() {
    violations++;
    const warning = document.getElementById('violationWarning');
    warning.textContent = `WARNING: Tab switch detected! (${violations}/${MAX_VIOLATIONS})`;
    warning.style.display = 'block';

    if (violations >= MAX_VIOLATIONS) {
        warning.textContent = 'Maximum violations reached. Quiz auto-submitted.';
        clearInterval(timerInterval);
        submitQuiz(true); // flagged
    }
}

// --- Submit ---
async function submitQuiz(flagged = false) {
    clearInterval(timerInterval);

    const form = new FormData();
    form.append('submission_id', submissionId);
    form.append('answers', JSON.stringify(answers));
    form.append('violations', violations);
    form.append('flagged', flagged ? '1' : '0');

    const resp = await fetch('../api/student/submit-quiz.php', { method: 'POST', body: form });
    const data = await resp.json();

    if (data.success) {
        sessionStorage.setItem('score', data.score);
        sessionStorage.setItem('total', data.total);
        window.location.href = 'result.php';
    } else {
        alert('Error submitting quiz: ' + data.error);
    }
}
```

**Step 4: Verify**
- Questions load without correct answers (check network tab)
- One question at a time, navigation works
- Timer counts down, auto-submits at 0
- Right-click disabled
- Copy/paste disabled
- Tab switch shows warning, 3 strikes auto-submits

---

### Task 5.4: Submit quiz + grading + email

**Objective:** Grade the quiz server-side, save answers, send email with score.

**Files:**
- Create: `api/student/submit-quiz.php`
- Create: `includes/mailer.php`
- Create: `student/result.php`

**Step 1: Write api/student/submit-quiz.php**

```php
<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/mailer.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$submissionId = (int)($_POST['submission_id'] ?? 0);
$answersJson  = $_POST['answers'] ?? '{}';
$violations   = (int)($_POST['violations'] ?? 0);
$flagged      = (int)($_POST['flagged'] ?? 0);

$answers = json_decode($answersJson, true);
if (!is_array($answers)) {
    $answers = [];
}

$pdo = getDB();

// Get submission
$stmt = $pdo->prepare(
    "SELECT s.*, q.title AS quiz_title, q.type, st.name AS student_name, st.email AS student_email
     FROM submissions s
     JOIN quizzes q ON s.quiz_id = q.quiz_id
     JOIN students st ON s.student_id = st.student_id
     WHERE s.submission_id = ?"
);
$stmt->execute([$submissionId]);
$submission = $stmt->fetch();

if (!$submission) {
    http_response_code(404);
    echo json_encode(['error' => 'Submission not found']);
    exit;
}

if ($submission['submitted_at']) {
    http_response_code(409);
    echo json_encode(['error' => 'Already submitted']);
    exit;
}

// Get questions with correct answers
$stmt = $pdo->prepare(
    "SELECT question_id, correct_answer FROM questions WHERE quiz_id = ? ORDER BY sort_order"
);
$stmt->execute([$submission['quiz_id']]);
$questions = $stmt->fetchAll();

// Grade
$score = 0;
$total = count($questions);

$insertStmt = $pdo->prepare(
    "INSERT INTO answers (submission_id, question_id, student_answer, is_correct) VALUES (?, ?, ?, ?)"
);

foreach ($questions as $q) {
    $studentAnswer = $answers[$q['question_id']] ?? null;
    $isCorrect = ($studentAnswer !== null && strtoupper($studentAnswer) === strtoupper($q['correct_answer'])) ? 1 : 0;
    if ($isCorrect) $score++;

    $insertStmt->execute([$submissionId, $q['question_id'], $studentAnswer, $isCorrect]);
}

// Update submission
$stmt = $pdo->prepare(
    "UPDATE submissions SET score = ?, total_items = ?, submitted_at = NOW(), violations = ?, flagged = ? WHERE submission_id = ?"
);
$stmt->execute([$score, $total, $violations, $flagged, $submissionId]);

// Send email
$emailTo = $submission['email_used'];
$subject = "Quiz Result: {$submission['quiz_title']}";
$body = "
Hello {$submission['student_name']},

You have completed the quiz: {$submission['quiz_title']}

Your score: {$score} out of {$total} (" . round(($score / max($total, 1)) * 100, 1) . "%)

" . ($flagged ? "NOTE: Your submission was flagged for tab-switching violations.\n" : "") . "
Thank you for participating.

— " . APP_NAME;

sendEmail($emailTo, $subject, $body);

echo json_encode([
    'success' => true,
    'score'   => $score,
    'total'   => $total,
]);
```

**Step 2: Write includes/mailer.php**

```php
<?php
// PHPMailer wrapper
// Install PHPMailer: composer require phpmailer/phpmailer
// Or download and place in vendor/ folder

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Autoload if using Composer
$autoloadPath = __DIR__ . '/../vendor/autoload.php';
if (file_exists($autoloadPath)) {
    require_once $autoloadPath;
}

function sendEmail(string $to, string $subject, string $body): bool {
    // If PHPMailer is not available, log to file instead
    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        $logDir = __DIR__ . '/../logs';
        if (!is_dir($logDir)) mkdir($logDir, 0755, true);
        file_put_contents(
            "$logDir/emails.log",
            date('Y-m-d H:i:s') . " | TO: $to | SUBJECT: $subject\n$body\n---\n",
            FILE_APPEND
        );
        return true; // Don't block submission if email fails
    }

    try {
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USER;
        $mail->Password   = SMTP_PASS;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;

        $mail->setFrom(SMTP_FROM, SMTP_FROM_NAME);
        $mail->addAddress($to);
        $mail->Subject = $subject;
        $mail->Body    = $body;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email failed: " . $mail->ErrorInfo);
        return false;
    }
}
```

**Step 3: Write student/result.php**

```php
<?php require_once __DIR__ . '/../config/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Result — <?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
</head>
<body>
<div class="student-container result-page">
    <h1>Quiz Completed!</h1>
    <div class="score-display">
        <p>Your Score:</p>
        <h2 id="scoreText"></h2>
        <p id="percentageText"></p>
    </div>
    <p>Your score has been sent to your email.</p>
    <a href="index.php">Take Another Quiz</a>
</div>

<script>
const score = sessionStorage.getItem('score');
const total = sessionStorage.getItem('total');

if (!score || !total) {
    window.location.href = 'index.php';
} else {
    const pct = Math.round((score / total) * 100);
    document.getElementById('scoreText').textContent = `${score} / ${total}`;
    document.getElementById('percentageText').textContent = `${pct}%`;
}

// Clear session
sessionStorage.clear();
</script>
</body>
</html>
```

**Step 4: Verify**
- Submit quiz → score calculated correctly
- Answers saved in DB
- Email sent (or logged)
- Result page shows score
- Session cleared

---

## Phase 6: Faculty — Grades Dashboard

### Task 6.1: Grades view + violation flags

**Objective:** Faculty can view all submissions per quiz, see scores, and identify flagged students.

**Files:**
- Create: `faculty/grades.php`
- Create: `api/faculty/grades.php`

**Step 1: Write api/faculty/grades.php**

```php
<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/auth.php';

$faculty = requireFaculty();
header('Content-Type: application/json');
$pdo = getDB();

$quizId = (int)($_GET['quiz_id'] ?? 0);

if ($quizId) {
    // Verify ownership
    $stmt = $pdo->prepare("SELECT 1 FROM quizzes WHERE quiz_id = ? AND faculty_id = ?");
    $stmt->execute([$quizId, $faculty['faculty_id']]);
    if (!$stmt->fetch()) {
        http_response_code(403);
        echo json_encode(['error' => 'Access denied']);
        exit;
    }

    $stmt = $pdo->prepare(
        "SELECT s.*, st.name AS student_name, st.year_section
         FROM submissions s
         JOIN students st ON s.student_id = st.student_id
         WHERE s.quiz_id = ?
         ORDER BY s.submitted_at DESC"
    );
    $stmt->execute([$quizId]);
} else {
    // All quizzes for this faculty
    $stmt = $pdo->prepare(
        "SELECT s.*, st.name AS student_name, q.title AS quiz_title
         FROM submissions s
         JOIN students st ON s.student_id = st.student_id
         JOIN quizzes q ON s.quiz_id = q.quiz_id
         WHERE q.faculty_id = ?
         ORDER BY s.submitted_at DESC"
    );
    $stmt->execute([$faculty['faculty_id']]);
}

echo json_encode($stmt->fetchAll());
```

**Step 2: Write faculty/grades.php**

```php
<?php
require_once __DIR__ . '/../includes/header.php';

$quizId = (int)($_GET['quiz_id'] ?? 0);
$pdo = getDB();

// Get quiz list for filter dropdown
$stmt = $pdo->prepare("SELECT quiz_id, title FROM quizzes WHERE faculty_id = ? ORDER BY created_at DESC");
$stmt->execute([$faculty['faculty_id']]);
$quizzes = $stmt->fetchAll();
?>

<h1>Grades</h1>

<form method="GET" style="margin-bottom:1rem;">
    <label>Filter by Quiz:
        <select name="quiz_id" onchange="this.form.submit()">
            <option value="">All Quizzes</option>
            <?php foreach ($quizzes as $q): ?>
                <option value="<?= $q['quiz_id'] ?>" <?= $quizId == $q['quiz_id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($q['title']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </label>
</form>

<table>
    <thead>
        <tr>
            <th>Student</th>
            <th>Quiz</th>
            <th>Score</th>
            <th>%</th>
            <th>Violations</th>
            <th>Flagged</th>
            <th>Submitted</th>
        </tr>
    </thead>
    <tbody id="gradesTable">Loading...</tbody>
</table>

<script>
async function loadGrades() {
    const quizId = <?= $quizId ?>;
    const url = `<?= BASE_URL ?>api/faculty/grades.php${quizId ? '?quiz_id=' + quizId : ''}`;
    const resp = await fetch(url);
    const grades = await resp.json();

    document.getElementById('gradesTable').innerHTML = grades.map(g => `
        <tr class="${g.flagged ? 'flagged-row' : ''}">
            <td>${g.student_name || g.student_id}</td>
            <td>${g.quiz_title || ''}</td>
            <td>${g.score} / ${g.total_items}</td>
            <td>${Math.round((g.score / g.total_items) * 100)}%</td>
            <td>${g.violations}</td>
            <td>${g.flagged ? '⚠️ FLAGGED' : '—'}</td>
            <td>${g.submitted_at || 'In progress'}</td>
        </tr>
    `).join('') || '<tr><td colspan="7">No submissions yet.</td></tr>';
}

loadGrades();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
```

**Step 3: Verify**
- All submissions visible
- Filter by quiz works
- Flagged students highlighted
- Scores and percentages correct

---

## Phase 7: CSS Styling

### Task 7.1: Write stylesheet

**Objective:** Clean, functional CSS for both student and faculty views.

**Files:**
- Create: `assets/css/style.css`

**Step 1: Write assets/css/style.css**

```css
/* ============================================================
   Online Quiz Generator — Stylesheet
   ============================================================ */

/* --- Reset --- */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    line-height: 1.6;
    color: #333;
    background: #f5f5f5;
}

/* --- Student Pages --- */
.student-container {
    max-width: 500px;
    margin: 80px auto;
    padding: 2rem;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.student-container h1 {
    text-align: center;
    margin-bottom: 1.5rem;
    color: #2c3e50;
}

.student-container label {
    display: block;
    margin-bottom: 1rem;
    font-weight: 500;
}

.student-container input[type="text"],
.student-container input[type="email"],
.student-container input[type="number"],
.student-container select,
.student-container textarea {
    width: 100%;
    padding: 0.6rem;
    margin-top: 0.25rem;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 1rem;
}

.student-container button,
button {
    width: 100%;
    padding: 0.7rem;
    background: #3498db;
    color: white;
    border: none;
    border-radius: 4px;
    font-size: 1rem;
    cursor: pointer;
    margin-top: 0.5rem;
}

button:hover { background: #2980b9; }
button:disabled { background: #bdc3c7; cursor: not-allowed; }

/* --- Quiz Page --- */
.quiz-body {
    background: #ecf0f1;
    user-select: none;
    -webkit-user-select: none;
}

.quiz-container {
    max-width: 700px;
    margin: 40px auto;
    padding: 2rem;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.1);
}

.quiz-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid #eee;
}

.quiz-header h1 { font-size: 1.3rem; color: #2c3e50; }

.timer {
    font-size: 1.5rem;
    font-weight: bold;
    font-family: monospace;
    color: #2c3e50;
}

.progress { color: #7f8c8d; font-size: 0.9rem; }

.question-card {
    margin-bottom: 1.5rem;
}

.question-card p {
    font-size: 1.1rem;
    margin-bottom: 1rem;
    font-weight: 500;
}

.option {
    display: block;
    padding: 0.8rem 1rem;
    margin-bottom: 0.5rem;
    border: 2px solid #ddd;
    border-radius: 6px;
    cursor: pointer;
    transition: border-color 0.2s;
}

.option:hover { border-color: #3498db; }
.option.selected { border-color: #3498db; background: #ebf5fb; }

.option input[type="radio"] { margin-right: 0.5rem; }

.quiz-nav {
    display: flex;
    gap: 0.5rem;
    margin-top: 1.5rem;
}

.quiz-nav button { flex: 1; }

/* --- Result Page --- */
.result-page { text-align: center; }

.score-display {
    margin: 2rem 0;
    padding: 2rem;
    background: #ebf5fb;
    border-radius: 8px;
}

.score-display h2 {
    font-size: 3rem;
    color: #2c3e50;
}

/* --- Faculty Pages --- */
.faculty-nav {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 0.8rem 2rem;
    background: #2c3e50;
    color: white;
}

.faculty-nav a {
    color: #ecf0f1;
    text-decoration: none;
    padding: 0.3rem 0.6rem;
    border-radius: 4px;
}

.faculty-nav a:hover { background: #34495e; }

.faculty-nav .brand { font-weight: bold; margin-right: auto; }
.faculty-nav .user { color: #bdc3c7; }

main {
    max-width: 1000px;
    margin: 2rem auto;
    padding: 0 1rem;
}

/* --- Tables --- */
table {
    width: 100%;
    border-collapse: collapse;
    margin: 1rem 0;
    background: white;
    border-radius: 6px;
    overflow: hidden;
    box-shadow: 0 1px 4px rgba(0,0,0,0.1);
}

th, td {
    padding: 0.7rem 1rem;
    text-align: left;
    border-bottom: 1px solid #eee;
}

th { background: #f8f9fa; font-weight: 600; }

tr:hover { background: #f8f9fa; }

.flagged-row { background: #fdf2f2; }
.flagged-row:hover { background: #fce8e8; }

/* --- Stats --- */
.stats {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
}

.stat-card {
    flex: 1;
    padding: 1.5rem;
    background: white;
    border-radius: 6px;
    text-align: center;
    box-shadow: 0 1px 4px rgba(0,0,0,0.1);
}

.stat-card h3 { font-size: 2rem; color: #3498db; }
.stat-card p { color: #7f8c8d; margin-top: 0.25rem; }

/* --- Forms (faculty) --- */
form label {
    display: block;
    margin-bottom: 0.8rem;
    font-weight: 500;
}

form input[type="text"],
form input[type="email"],
form input[type="number"],
form input[type="password"],
form select,
form textarea {
    width: 100%;
    padding: 0.5rem;
    margin-top: 0.2rem;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 0.95rem;
}

form textarea { min-height: 80px; resize: vertical; }

form button {
    width: auto;
    padding: 0.6rem 1.5rem;
}

/* --- Question items --- */
.question-item {
    padding: 0.8rem;
    margin-bottom: 0.5rem;
    background: #f8f9fa;
    border-radius: 4px;
    border-left: 3px solid #3498db;
}

.question-item button {
    width: auto;
    padding: 0.3rem 0.8rem;
    font-size: 0.85rem;
    background: #e74c3c;
    margin-top: 0.3rem;
}

.question-item button:hover { background: #c0392b; }

/* --- Login --- */
.login-container {
    max-width: 400px;
    margin: 100px auto;
    padding: 2rem;
    background: white;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.login-container h1 {
    text-align: center;
    margin-bottom: 1.5rem;
}

/* --- Responsive --- */
@media (max-width: 600px) {
    .faculty-nav { flex-wrap: wrap; padding: 0.5rem 1rem; }
    .stats { flex-direction: column; }
    .quiz-header { flex-direction: column; gap: 0.5rem; }
}
```

**Step 2: Verify**
- All pages styled consistently
- Mobile responsive
- Flagged rows highlighted
- Quiz options have clear selected state

---

## Phase 8: Deploy to Hostinger

### Task 8.1: Deployment preparation

**Objective:** Prepare files for Hostinger upload, create seed data, write deploy instructions.

**Files:**
- Create: `.htaccess`
- Create: `seed.php` (create first faculty account)
- Create: `DEPLOY.md`

**Step 1: Write .htaccess**

```apache
# Disable directory listing
Options -Indexes

# Protect config files
<FilesMatch "\.(env|config)$">
    Order allow,deny
    Deny from all
</FilesMatch>

# Protect includes directory
RewriteEngine On
RewriteRule ^includes/ - [F,L]
RewriteRule ^config/ - [F,L]
RewriteRule ^api/ - [F,L]

# Pretty URLs (optional)
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ index.php [QSA,L]
```

**Step 2: Write seed.php (run once to create first faculty account)**

```php
<?php
// Run this ONCE to create the first faculty account, then DELETE this file.
// Usage: visit https://yourdomain.com/quiz-gen/seed.php

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

$pdo = getDB();

// Check if faculty table is empty
$stmt = $pdo->query("SELECT COUNT(*) FROM faculty");
if ($stmt->fetchColumn() > 0) {
    die("Faculty already exists. Delete this file.");
}

$name     = 'Admin';
$email    = 'admin@example.com';     // CHANGE THIS
$password = 'changeme123';           // CHANGE THIS
$hash     = password_hash($password, PASSWORD_BCRYPT);

$stmt = $pdo->prepare("INSERT INTO faculty (name, email, password_hash) VALUES (?, ?, ?)");
$stmt->execute([$name, $email, $hash]);

echo "Faculty account created!<br>";
echo "Email: $email<br>";
echo "Password: $password<br>";
echo "<strong>DELETE THIS FILE NOW.</strong>";
```

**Step 3: Write DEPLOY.md**

```markdown
# Deploy to Hostinger

## 1. Upload Files
- Upload all files to `public_html/quiz-gen/` (or your preferred subdirectory)
- Use Hostinger File Manager or FTP

## 2. Create Database
- Go to Hostinger → MySQL Databases
- Create a new database (e.g., `u123456789_quiz`)
- Create a database user with full privileges
- Open phpMyAdmin → Import → select `schema.sql`

## 3. Update Config
Edit `config/database.php`:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'u123456789_quiz');
define('DB_USER', 'u123456789_quizuser');
define('DB_PASS', 'your-db-password');
```

Edit `config/config.php`:
```php
define('BASE_URL', 'https://yourdomain.com/quiz-gen/');
// Update SMTP settings
define('SMTP_HOST', 'smtp.hostinger.com');
define('SMTP_USER', 'noreply@yourdomain.com');
define('SMTP_PASS', 'your-email-password');
define('SMTP_FROM', 'noreply@yourdomain.com');
```

## 4. Install PHPMailer
Option A — Composer (if SSH available):
```bash
cd public_html/quiz-gen
composer require phpmailer/phpmailer
```

Option B — Manual:
- Download PHPMailer from https://github.com/PHPMailer/PHPMailer
- Extract `src/` folder into `vendor/phpmailer/phpmailer/src/`

## 5. Create Faculty Account
- Visit `https://yourdomain.com/quiz-gen/seed.php`
- Note the credentials
- **DELETE seed.php immediately after**

## 6. Test
- Visit `https://yourdomain.com/quiz-gen/student/`
- Enter a test student ID and quiz ID
- Faculty login at `https://yourdomain.com/quiz-gen/faculty/login.php`
```

**Step 4: Verify**
- .htaccess blocks sensitive directories
- seed.php creates faculty account
- DEPLOY.md has complete instructions

---

## Summary

**Total files:** 24 files across 8 phases

**Phase 1:** schema.sql, config/database.php, config/config.php
**Phase 2:** faculty/login.php, api/faculty/login.php, api/faculty/logout.php, includes/auth.php, faculty/dashboard.php, includes/header.php, includes/footer.php
**Phase 3:** faculty/quiz-create.php, api/faculty/quizzes.php, faculty/quiz-edit.php, api/faculty/questions.php
**Phase 4:** faculty/students.php, api/faculty/students.php
**Phase 5:** index.php, student/index.php, api/student/verify.php, student/email.php, student/quiz.php, api/student/start-quiz.php, assets/js/quiz.js, api/student/submit-quiz.php, includes/mailer.php, student/result.php
**Phase 6:** faculty/grades.php, api/faculty/grades.php
**Phase 7:** assets/css/style.css
**Phase 8:** .htaccess, seed.php, DEPLOY.md

**Key security measures:**
- Correct answers never sent to browser
- PDO prepared statements everywhere (no SQL injection)
- Password hashing with bcrypt
- Session-based faculty auth with httponly cookies
- Config files blocked via .htaccess
- Anti-cheat: no right-click, no copy/paste, tab-switch detection, timer

**Ready to implement.** Shall I start building phase by phase?
